# Q Testnet node installation guide 


<details><summary>Official links</summary>
  
Website - [https://q.org/](https://q.org/)
  
Mainnet - [https://hq.q.org/](https://hq.q.org/)
  
Testnet - [https://hq.qtestnet.org/](https://hq.qtestnet.org/)
  
ChainList - [https://chainlist.org/chain/35441](https://chainlist.org/chain/35441)
  
Medium - [https://medium.com/q-blockchain](https://medium.com/q-blockchain)
  
Reddit - [https://www.reddit.com/r/QBlockchain/](https://www.reddit.com/r/QBlockchain/)
  
Twitter - [https://twitter.com/QBlockchain](https://twitter.com/QBlockchain) 
  
</details>

<details><summary>Constitution & Whitepaper</summary>
  
Constitution - [https://q.org/assets/files/Q_Constitution.pdf](https://q.org/assets/files/Q_Constitution.pdf)
  
Whitepaper - [https://q.org/assets/files/Q Whitepaper_v1.0.pdf](https://q.org/assets/files/Q%20Whitepaper_v1.0.pdf)
  
</details>
    
<details><summary>Faucet</summary>
https://faucet.qtestnet.org/](https://faucet.qtestnet.org/)
</details>

<details><summary>Documentation</summary>
  
Documentation - [https://docs.q.org/](https://docs.q.org/)
    
Source Code - [https://gitlab.com/q-dev](https://gitlab.com/q-dev)
    
Security Audit - [https://medium.com/q-blockchain/q-system-contracts-security-audit-e101ea356586](https://medium.com/q-blockchain/q-system-contracts-security-audit-e101ea356586)
  
</details>

<details><summary>Explorer</summary>
  
[https://explorer.qtestnet.org/](https://explorer.qtestnet.org/) 
    
[https://stats.qtestnet.org/](https://stats.qtestnet.org/)
    
[https://explorer.qtestnet.org/graphiql](https://explorer.qtestnet.org/graphiql)
  
</details>
    
<details><summary>Official guide</summary>
  
[https://docs.qtestnet.org/how-to-setup-validator/](https://docs.qtestnet.org/how-to-setup-validator/)
  
</details>
</br>        
 
 ## Минимальные характеристики сервера
• 6 Cores

• 8 GB RAM

• 250 GB SSD
 
## Установка
    
Клонируем репозиторий и переходим в каталог /testnet-validator
    
```bash
git clone https://gitlab.com/q-dev/testnet-public-tools 
cd testnet-public-tools/testnet-validator
```
    
Далее, создаем текстовый файл pwd.txt с паролем который находится в каталоге `testnet-public-tools/testnet-validator/keystore/`
    
```bash
cd $HOME/testnet-public-tools/testnet-validator/
mkdir keystore
cd keystore
nano pwd.txt
# придумываем пароль и вписываем, не забудьте его сохранить (без кавычек) 
# далее закрываем nano Ctrl+o enter Ctrl+x
```
    
## Generate a Keypair for Validator
Создается `.json` файл кошелька который находится в каталоге `/root/testnet-public-tools/testnet-validator/keystore/` - даный ключ экспортируем в `Metamask` , так же данный кошелек нужно указать в форме. Пароль от этого кошелька записан в `pwd.txt`.

</br>

```bash
cd $HOME/testnet-public-tools/testnet-validator/
docker-compose run --rm --entrypoint "geth account new --datadir=/data --password=/data/keystore/pwd.txt" testnet-validator-node

# вывод:

# Your new key was generated
    
# Public address of the key:   0xb3FF24F818b0ff6Cc50de951bcB8f86b52287dac
# Path of the secret key file: /data/keystore/UTC--2021-01-18T11-36-28.705754426Z--b3ff24f818b0ff6cc50de951bcb8f86b52287dac
    
# - You can share your public address with anyone. Others need it to interact with you.
# - You must NEVER share the secret key with anyone! The key controls access to your funds!
# - You must BACKUP your key file! Without the key, it's impossible to access account funds!
# - You must REMEMBER your password! Without the password, it's impossible to decrypt the key!
```
    

> 💡 Не забываем сохранять пароли и Ключи (UTC--…)

    
Нужно 2 кошелька эфириум - для ревардов и тестовый, для удобства добавляем в основной кошелек Метамаск наш тестовый сгененрированный кошелек. 
    
Для этого: 
- в `Metamask` `Импортировать счет` Выбрать тип `Файл JSON` 
    
- Выбираем ключ из каталога `../keystore` (пример: `UTC--2021-01-18T11-36-28.705754426Z--b3ff24f818b0ff6cc50de951bcb8f86b52287dac`) 
    
- Вводим пароль (`pwd.txt`)
    
- Ждем минут 10

## Создаем валидатора
Переходим на сайт [`https://hq.qtestnet.org/`](https://hq.qtestnet.org/), коннектим тестовый кошелек`Connect to Q Testnet` 
    
Включаем `Advanced mode`, переходим в `Validator Staiking`, вводим количество `Amount` и стейкаем `Stake to Ranking`, после чего присоединяемся `Join Validator Ranking`   
    
Монеты получаем из крана -  [Faucet](https://faucet.qtestnet.org/)
    
![Q.png](assets/Q.png)
    
## Configure Setup
    
Редактируем файл `.env` 
    
```bash
    cd $HOME/testnet-public-tools/testnet-validator/
    nano .env
    
    # сохранить и закрыть nano Ctrl+o enter Ctrl+x
```
    
в строчку `ADDRESS=`вставляем ваш адрес без 0x

в строчку `IP=` вставляем ваш ip

![1.png](assets/1.png)
    
Редактируем файл `config.json`
    
```bash
    cd $HOME/testnet-public-tools/testnet-validator/
    nano config.json
    
    # сохранить и закрыть nano Ctrl+o enter Ctrl+x
```
    
в строчку `"address":` в кавычки вставляем ваш адрес без 0x
в строчку `"password":` в кавычки вставляем ваш пароль который вписывали в `pwd.txt`
    
## Регистрируем валидатора
    
Заполняем форму - [https://itn.qdev.li/](https://itn.qdev.li/)
    
Записываем Имя валидатора - его нужно будет вставить в `docker-compose.yaml`
    
![2.png](assets/2.png)
    
Редактируем файл `docker-compose.yaml` 
    
```bash
    cd $HOME/testnet-public-tools/testnet-validator/
    nano docker-compose.yaml
```
    
Удаляем всё (удалить строчку целиком `Ctrl+k` ). Вставляем как ниже и изменяем Имя валидатора на свое в строке `"--ethstats=`
    
```bash
    version: "3"
    
    services:
      testnet-validator-node:
        image: $QCLIENT_IMAGE
        entrypoint: [
          "geth",
          "--testnet",
          "--datadir=/data",
          "--syncmode=full",
          "--ethstats=<ИМЯ_ВАЛИДАТОРА>:qstats-testnet@stats.qtestnet.org",
          "--whitelist=3699041=0xabbe19ba455511260381aaa7aa606b2fec2de762b9591433bbb379894aba55c1",
          "--bootnodes=$BOOTNODE1_ADDR,$BOOTNODE2_ADDR,$BOOTNODE3_ADDR",
          "--verbosity=3",
          "--nat=extip:$IP",
          "--port=$EXT_PORT",
          "--unlock=$ADDRESS",
          "--password=/data/keystore/pwd.txt",
          "--mine",
          "--miner.threads=1",
          "--miner.gasprice=1",
          "--rpc.allow-unprotected-txs"
        ]
        volumes:
          - ./keystore:/data/keystore
          - ./additional:/data/additional
          - testnet-validator-node-data:/data
        ports:
          - $EXT_PORT:$EXT_PORT
          - $EXT_PORT:$EXT_PORT/udp
        restart: unless-stopped
    
    volumes:
      testnet-validator-node-data:
    
    # сохранить и закрыть nano Ctrl+o enter Ctrl+x
```
    
## Запускаем ноду
    
```bash
    cd $HOME/testnet-public-tools/testnet-validator/
    docker-compose up -d
```
    
Посмотреть логи 
    
```bash
    docker-compose logs -f --tail "100"
```

## Если не находит пиры долгое время (2-3часа)

Нужно добавить пиры в файлы `.env` и отредактировать `doker-compose.yaml`

.env
```bash
cd $HOME/testnet-public-tools/testnet-validator/
nano .env
# добавить пиры 
BOOTNODE4_ADDR=enode://a3862c64d5d7e43f8cffce810d4ad00d20c2b34524df20be5c3e9a91f157a7ca532068e358e690453e3f339d5bdeab6a922d7a2a6243d4c89d4b64304360de1e@18.158.211.67:30303
BOOTNODE5_ADDR=enode://a8f808a716c6235aca81197af4bd36b0505550c87ba09c2e2c2435b347e9a016ca40527d90fc5e8f8400d7bd7dbc1339a9c8f190c2a883c1f2dea6716e3213ff@92.169.114.234:30314
```

docker-compose.yaml
```bash
cd $HOME/testnet-public-tools/testnet-validator/
nano docker-compose.yaml
# в строку "--bootnodes=..." добавить
$BOOTNODE5_ADDR
$BOOTNODE4_ADDR
```

   
## Баг на блоке 3,699,041
    
На блоке **3,699,041**  сеть перестает синхронизироваться, поэтому чтобы его “проскочить” в  консоли необходимо ввести команду ниже и перезагрузить ноду  
    
```bash
    cd $HOME/testnet-public-tools/testnet-validator/
    
    # переходим в консоль
    docker-compose exec testnet-validator-node geth attach /data/geth.ipc
    
    # вводим команду
    debug.setHead(web3.toHex(3699040))
    
    # закрыть консоль: ctrl+d или exit 
    
    # перезагружаем ноду
    docker-compose down && docker-compose up -d
```

## Работа с нодой
 Для того чтобы обновить ноду, извлечь ключ, создать аккаунт и др используем следующую команду:
 
 ```bash
 wget -q -O q.sh https://gitlab.com/q-dev/testnet-public-tools/-/snippets/2473910/raw/main/q.sh && chmod +x q.sh && /bin/bash q.sh
 ```
    
   ![3.png](assets/3.png)

## Special thanks

[@nil1oki](https://github.com/nil1oki) - creating, 
[@roadd](https://github.com/ryssroad) -formatting
